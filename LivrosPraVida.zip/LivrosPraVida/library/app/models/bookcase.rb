class Bookcase < ApplicationRecord
end

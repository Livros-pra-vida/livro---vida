class CreateUsers < ActiveRecord::Migration[8.1]
  def change
    create_table :users do |t|
      t.string :username
      t.boolean :age_verified
      t.string :email
      t.string :password_digest
      t.string :admin
      t.string :boolean

      t.timestamps
    end
  end
end
